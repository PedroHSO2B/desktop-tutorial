function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('rgb(74,240,74)');
  fill('rgb(0,233,255)');
  circle(200,200,300);
  fill('white');
  circle(150,150,60);
  circle(250,150,60);
  line(130,250,260,250);
  fill('orange');
  triangle(200,180,170,220,220,220);
  line(120,110,170,110);
  line(230,110,280,110);
  //circle(150,150,10);
  //circle(250,150,10);
  
  olhoX = map(mouseX,0,400,130,170);
  olhoY = map(mouseY,0,400,130,170);
  
  circle(olhoX,olhoY,10);
  circle(olhoX+100,olhoY,10);
  
  if(mouseIsPressed){
     console.log(mouseX,mouseY);
     }
}